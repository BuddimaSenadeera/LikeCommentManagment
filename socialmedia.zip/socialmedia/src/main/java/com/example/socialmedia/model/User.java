// User.java
package com.example.socialmedia.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer userId;
    private String username;
    private String email;
    private String passwordHash;
    private LocalDateTime createdAt = LocalDateTime.now();
    // Getters and Setters
}
