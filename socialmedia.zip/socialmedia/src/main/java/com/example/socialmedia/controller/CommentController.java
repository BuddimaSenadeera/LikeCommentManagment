// CommentController.java
package com.example.socialmedia.controller;

import com.example.socialmedia.model.Comment;
import com.example.socialmedia.model.Post;
import com.example.socialmedia.repository.CommentRepository;
import com.example.socialmedia.repository.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/comments")
public class CommentController {
    @Autowired
    private CommentRepository commentRepo;
    @Autowired
    private PostRepository postRepo;

    @PostMapping("/add")
    public ResponseEntity<?> addComment(@RequestParam Integer userId, @RequestParam Integer postId, @RequestBody String content) {
        if (postRepo.findById(postId).isEmpty()) return ResponseEntity.status(404).body("Post not found");
        Comment comment = new Comment();
        comment.setUserId(userId);
        comment.setPostId(postId);
        comment.setContent(content);
        commentRepo.save(comment);
        return ResponseEntity.ok("Comment added");
    }

    @PutMapping("/edit/{commentId}")
    public ResponseEntity<?> editComment(@PathVariable Integer commentId, @RequestParam Integer userId, @RequestBody String content) {
        Optional<Comment> comment = commentRepo.findById(commentId);
        if (comment.isEmpty()) return ResponseEntity.status(404).body("Comment not found");
        if (!comment.get().getUserId().equals(userId)) return ResponseEntity.status(403).body("Not allowed");
        comment.get().setContent(content);
        comment.get().setUpdatedAt(LocalDateTime.now());
        commentRepo.save(comment.get());
        return ResponseEntity.ok("Comment updated");
    }

    @DeleteMapping("/delete/{commentId}")
    public ResponseEntity<?> deleteOwn(@PathVariable Integer commentId, @RequestParam Integer userId) {
        Optional<Comment> comment = commentRepo.findById(commentId);
        if (comment.isEmpty()) return ResponseEntity.status(404).body("Not found");
        if (!comment.get().getUserId().equals(userId)) return ResponseEntity.status(403).body("Not allowed");
        comment.get().setIsDeleted(true);
        commentRepo.save(comment.get());
        return ResponseEntity.ok("Comment deleted");
    }

    @DeleteMapping("/owner-delete/{commentId}")
    public ResponseEntity<?> deleteByOwner(@PathVariable Integer commentId, @RequestParam Integer userId) {
        Optional<Comment> comment = commentRepo.findById(commentId);
        if (comment.isEmpty()) return ResponseEntity.status(404).body("Not found");
        Optional<Post> post = postRepo.findById(comment.get().getPostId());
        if (post.isEmpty()) return ResponseEntity.status(404).body("Post not found");
        if (!post.get().getUserId().equals(userId)) return ResponseEntity.status(403).body("Not post owner");
        comment.get().setIsDeleted(true);
        commentRepo.save(comment.get());
        return ResponseEntity.ok("Comment deleted by owner");
    }

    @GetMapping("/post/{postId}")
    public ResponseEntity<?> getComments(@PathVariable Integer postId) {
        List<Comment> comments = commentRepo.findByPostId(postId).stream()
                .filter(c -> !c.getIsDeleted())
                .toList();
        return ResponseEntity.ok(comments);
    }
}