// LikeController.java
package com.example.socialmedia.controller;

import com.example.socialmedia.model.Like;
import com.example.socialmedia.repository.LikeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Optional;

@RestController
@RequestMapping("/api/likes")
public class LikeController {
    @Autowired
    private LikeRepository likeRepository;

    @PostMapping("/like")
    public ResponseEntity<?> likePost(@RequestParam Integer userId, @RequestParam Integer postId) {
        Optional<Like> existing = likeRepository.findByUserIdAndPostId(userId, postId);
        if (existing.isPresent()) return ResponseEntity.badRequest().body("Already liked");
        Like like = new Like();
        like.setUserId(userId);
        like.setPostId(postId);
        likeRepository.save(like);
        return ResponseEntity.ok("Liked");
    }

    @DeleteMapping("/unlike")
    public ResponseEntity<?> unlikePost(@RequestParam Integer userId, @RequestParam Integer postId) {
        Optional<Like> existing = likeRepository.findByUserIdAndPostId(userId, postId);
        if (existing.isEmpty()) return ResponseEntity.status(404).body("Not liked");
        likeRepository.delete(existing.get());
        return ResponseEntity.ok("Unliked");
    }
}